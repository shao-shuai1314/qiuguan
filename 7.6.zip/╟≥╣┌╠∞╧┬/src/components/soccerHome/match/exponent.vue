<template>
  <div>球冠指数</div>
</template>
<script >
export default {
  name: 'HelloWorld',
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
</style>