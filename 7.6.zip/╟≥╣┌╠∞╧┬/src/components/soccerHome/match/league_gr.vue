<template>
  <div class="history_right">
    <!-- 主场积分榜 -->
    <table width="100%"
           v-for="(item,index) in leagueList"
           :key="index"
           border="0"
           cellpadding="0"
           cellspacing="0"
           align="center"
           class="table1">
      <tr align="center"
          class="tit">
        <td colspan="7">
          {{item.style}}积分榜
        </td>

      </tr>
      <tr align="center"
          class="tr_tit">
        <td>排名</td>
        <td>球队</td>
        <td>赛</td>
        <td>胜</td>
        <td>平</td>
        <td>负</td>
        <td>分</td>
      </tr>

      <tr align="center"
          v-for="i in item.list"
          :key="i.rank"
          :style="{'background-color': (i.teamName ===datas[0] || i.teamName ===datas[1] ? '#ffffb1':'')}">
        <td>{{i.rank}}</td>
        <td>{{i.teamName}}</td>
        <td>{{i.allCount}}</td>
        <td>{{i.win_score}}</td>
        <td>{{i.flat_score}}</td>
        <td>{{i.totalHomeScore}}</td>
        <td>{{i.allScore}}</td>

      </tr>

    </table>
  </div>
</template>
<script >
export default {
  data () {
    return {
      leagueList: {
        homeLeagueList: { style: "主场", list: [] },
        guestLeagueList: { style: "客场", list: [] },
        allLeagueList: { style: "总", list: [] },
      },
      sclassID: '',
    }
  },
  props: ["datas"],
  created () {
    // console.log(this.datas[3])

  },
  mounted () {
    // this.OnleagueList()
  },

  watch: {
    datas: function (val) {
      //  console.log('val监听:',val[2])
      // this.sclassID = val[2]

      //  this.OnleagueList(val[2])
      if (this.sclassID != val[2]) {
        this.sclassID = val[2]
        // console.log(1111)
        this.OnleagueList()
      }

    },

  },
  methods: {
    async OnleagueList () {
      let obj = {}
      // obj.sclassID=this.sclassID;
      if (!this.sclassID) {
        obj.sclassID = this.datas[2]
      } else {
        obj.sclassID = this.sclassID;
      }
      // console.log(this.sclassID)
      // if()
      obj.matchSeason = this.datas[3];
      obj.homeOrGuest = 'home';
      // 主队
      if (obj.sclassID && obj.matchSeason) {
        const homeres = await this.$http.get('soccer/league/', { params: obj });
        if (homeres.status !== 200) return console.log('主队积分榜信息取失败')

        this.leagueList.homeLeagueList.list = homeres.data.leagueList
      }

      //   客队
      obj.homeOrGuest = 'guest';
      if (obj.sclassID && obj.matchSeason) {
        const guestres = await this.$http.get('soccer/league/', { params: obj });
        if (guestres.status !== 200) return console.log('客队积分榜信息取失败')
        this.leagueList.guestLeagueList.list = guestres.data.leagueList
      }
      //   总
      obj.homeOrGuest = ' ';
      if (obj.sclassID && obj.matchSeason) {
        const allres = await this.$http.get('soccer/league/', { params: obj });
        if (allres.status !== 200) return console.log('客队积分榜信息取失败')
        this.leagueList.allLeagueList.list = allres.data.leagueList
      }
    }
  }
}
</script>
<style lang = 'less' scoped >
.history_right {
  width: 280px;
  .table1 {
    border: 1px solid #91c1f8;
    box-sizing: border-box;
    font-size: 12px;
    margin-bottom: 10px;
    tr {
      width: 100%;
      height: 24px;
    }
    .tr_tit {
      background: #f0f0f0;
      height: 36px;
    }
    .tit {
      background: #91c1f8;
      height: 36px;
      color: #fff;
    }
  }
}
</style>