<template>
  <div class="gWidth">
    <div class="left_box fl">
      <el-card>
        <div class="player_header">
          <div class="player_header_left">
            <h3>{{headerData.name_j}}</h3>
            <p>{{headerData.name_e}}</p>
            <div class="details">
              <dl>
                <dd v-if="headerData.place">俱乐部：{{headerData.place[0].teamID__name_j}}</dd>
                <dd v-if="headerData.place">位置：{{headerData.place[0].place}}</dd>
                <dd v-if="headerData.place">号码：{{headerData.place[0].number}}号</dd>
              </dl>
              <dl>
                <dd>国籍：{{headerData.country}}</dd>
                <dd>年龄：31岁</dd>
                <dd>生日：{{headerData.birthday}}</dd>
              </dl>
              <dl>
                <dd>身高：{{headerData.tallness}}CM</dd>
                <dd>体重：{{headerData.weight}}KG</dd>
                <dd>惯用脚：右脚</dd>
              </dl>
            </div>
          </div>
          <div class="player_header_right">
            <el-image :src="`http://info.win007.com/Image/team/${headerData.photo}`"></el-image>
          </div>

        </div>
      </el-card>
      <!-- 左下内容 -->
      <el-card class="left_box_bottom">

        <div>
          <!-- 比赛数据 -->
          <el-divider content-position="left">
            <h6>比赛数据</h6>
          </el-divider>
          <el-tabs v-model="activeName"
                   @tab-click="handleClick">
            <el-tab-pane label="总计"
                         name="totalize">
              <div>
                <table width="100%"
                       border="0"
                       cellpadding="0"
                       cellspacing="0"
                       align="center"
                       class="table_NeiRong">
                  <tr align="center"
                      class="table_NeiRong_one">
                    <td width="20%">赛季</td>
                    <td width="20%">俱乐部</td>
                    <td width="10%">上场</td>
                    <td width="10%">首发</td>
                    <td width="10%">进球</td>
                    <td width="10%">助攻</td>
                    <td width="10%">黄牌</td>
                    <td width="10%">红牌</td>
                  </tr>
                  <tr align="center"
                      v-for="item in 10"
                      :key="item"
                      class="">
                    <td width="20%">赛季</td>
                    <td width="20%">俱乐部</td>
                    <td width="10%">上场</td>
                    <td width="10%">首发</td>
                    <td width="10%">进球</td>
                    <td width="10%">助攻</td>
                    <td width="10%">黄牌</td>
                    <td width="10%">红牌</td>
                  </tr>
                </table>

              </div>

            </el-tab-pane>
            <el-tab-pane label="联赛"
                         name="leagueMatches">
              <div class="wusj"> 暂无数据</div>
            </el-tab-pane>
            <el-tab-pane label="角色管理"
                         name="杯赛">
              <div class="wusj"> 暂无数据</div>
            </el-tab-pane>
            <el-tab-pane label="国家队"
                         name="cupCompetition">
              <div class="wusj"> 暂无数据</div>
            </el-tab-pane>
          </el-tabs>
        </div>

        <div class="kua">
          <!-- 获得荣誉 -->
          <el-divider content-position="left">
            <h6>获得荣誉</h6>
          </el-divider>
          <div class="wusj"> 暂无数据</div>
        </div>

        <div class="kua zhuanh">
          <!-- 转会 -->
          <el-divider content-position="left">
            <h6>转会</h6>
          </el-divider>
          <dl>
            <dd>
              <p>2018-01-08</p>
              <p>汉堡 &nbsp;&nbsp;&nbsp;
                <i class="el-icon-right"></i>&nbsp;&nbsp;&nbsp; 拜仁慕尼黑 </p>
              <p>转会（300万欧元）</p>
            </dd>
            <dd>
              <p>2018-01-08</p>
              <p>汉堡 &nbsp;&nbsp;&nbsp;
                <i class="el-icon-right"></i> &nbsp;&nbsp;&nbsp;拜仁慕尼黑 </p>
              <p>转会（300万欧元）</p>
            </dd>
          </dl>
        </div>

        <div class="kua zhuanh">
          <!-- 伤病 -->
          <el-divider content-position="left">
            <h6>伤病</h6>
          </el-divider>
          <dl>
            <dd>
              <p>拜仁慕尼黑</p>
              <p>膝盖受伤</p>
              <p>2020-10-18 ~ 2020-11-10</p>
            </dd>
            <dd>
              <p>拜仁慕尼黑</p>
              <p>膝盖受伤</p>
              <p>2020-10-18 ~ 2020-11-10</p>
            </dd>
          </dl>
        </div>
      </el-card>

    </div>

    <!-- 右边内容 -->
    <el-card class="right_box fr">
      <h6>相关队员</h6>
      <!-- 前锋 -->
      <dl>
        <dd class="dd-h">
          <p>前锋</p>
          <p>进球</p>
          <p>国籍</p>
        </dd>
        <dd v-for="item in 6"
            :key="item">
          <p>
            <el-image></el-image>
            <router-link to="">莱万特朵夫斯基</router-link>
          </p>
          <p>40</p>
          <p>
            <el-image></el-image>
          </p>
        </dd>
      </dl>
      <!-- 中长 -->
      <dl>
        <dd class="dd-h">
          <p>中场</p>
          <p>进球</p>
          <p>国籍</p>
        </dd>
        <dd v-for="item in 6"
            :key="item">
          <p>
            <el-image></el-image>
            <router-link to="">莱万特朵夫斯基</router-link>
          </p>
          <p>40</p>
          <p>
            <el-image></el-image>
          </p>
        </dd>
      </dl>

      <!-- 后卫 -->
      <dl>
        <dd class="dd-h">
          <p>后卫</p>
          <p>进球</p>
          <p>国籍</p>
        </dd>
        <dd v-for="item in 6"
            :key="item">
          <p>
            <el-image></el-image>
            <router-link to="">莱万特朵夫斯基</router-link>
          </p>
          <p>40</p>
          <p>
            <el-image></el-image>
          </p>
        </dd>
      </dl>
    </el-card>

  </div>
</template>
<script >
export default {
  data () {
    return {
      scheduleID: '',
      activeName: 'totalize',
      headerData: []
    };
  },
  created () {
    this.scheduleID = this.$route.params.playerID
    // console.log(this.$route.name)
    this.dataList1()
  },
  methods: {
    handleClick (tab, event) {
      console.log(tab, event);
    },
    async dataList1 () {
      const res = await this.$http.get('teamInfo/player/' + this.scheduleID);
      if (res.status !== 200) return console.log('对阵头部信息取失败');
      this.headerData = res.data
      console.log(res.data)
    }
  }
}
</script>
<style lang = 'less' scoped >
.el-card {
  margin-bottom: 10px;
  width: 872px;
}
.player_header {
  display: flex;
  justify-content: space-around;
  align-items: center;
  .player_header_left {
    width: 530px;
    h3 {
      font-size: 26px;
      color: #25180b;
      line-height: 38px;
      font-weight: 600;
    }
    p {
      color: #a8a5a4;
      font-size: 14px;
      margin-bottom: 8px;
    }
    .details {
      width: 100%;
      display: flex;
      justify-content: space-between;
      dl {
        dd {
          line-height: 28px;
          color: #050200;
        }
      }
    }
  }
  .player_header_right {
    width: 150px;
    height: 150px;
    .el-image {
      width: 100%;
      height: 100%;
    }
  }
}

.left_box_bottom {
  h6 {
    font-size: 18px;
    font-weight: 600;
  }
  .wusj {
    text-align: center;
  }
  .kua {
    padding: 20 px;
  }
  .table_NeiRong {
    color: #555;
    tr {
      height: 30px;
      font-size: 14px;
      /* &:nth-child(2n) {
        background: #f7f7f7;
      } */
    }
    td {
      border-bottom: 1px solid #ececec;
    }
    .table_NeiRong_one {
      background: #f3f4ef;
      font-size: 16px;
      /* height: 50px; */
    }
    .table_NeiRong_two {
      &:hover {
        background: #f3f4ef;
      }
    }
  }
  .zhuanh {
    dl {
      dd {
        border-bottom: 1px solid #ececec;
        height: 30px;
        line-height: 30px;
        display: flex;
        justify-content: space-around;
        p {
          font-size: 14px;
          width: 33.33%;
          text-align: center;
        }
      }
    }
  }
}
/* 右边内容 */
.right_box {
  width: 316px;
  /* height: 1000px; */
  h6 {
    font-size: 18px;
    font-weight: 600;
  }
  dl {
    dd {
      width: 100%;
      display: flex;
      justify-content: space-between;
      border-bottom: 1px solid #ececec;
      p {
        display: flex;
        justify-content: center;
        align-items: center;
        line-height: 40px;
        &:nth-child(1) {
          width: 60%;
          .el-image {
            width: 20px;
            height: 24px;
            margin-right: 6px;
          }
        }
        &:nth-child(2) {
          width: 20%;
        }
        &:nth-child(3) {
          width: 20%;
          .el-image {
            width: 24px;
            height: 10px;
          }
        }
        font-size: 14px;
      }
    }
    .dd-h {
      background: #f3f4ef;
      margin-top: 20px;
      p {
        font-weight: 600;
      }
    }
  }
}
</style>