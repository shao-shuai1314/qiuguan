<template>
  <div>
    求援数据
  </div>
</template>
<script >
export default {
  name: 'HelloWorld',
  data () {
    return {
    };
  },
  methods: {
  }
}
</script>
<style lang = 'less' scoped >
</style>