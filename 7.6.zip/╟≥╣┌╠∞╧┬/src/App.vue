<template>
  <div id="app"
       :key="Key">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      Key: ''
    };
  },
  watch: {
    $route: function (newUrl, oldUrl) {
      this.Key = new Date().getTime();
    }
  }
}
</script>

<style>
</style>
